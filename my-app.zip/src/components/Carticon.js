import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCartPlus } from '@fortawesome/free-solid-svg-icons';

const Carticon = () => {

    return (
            <div>
            <a className="cart-link" to="#"><FontAwesomeIcon icon={faCartPlus} ></FontAwesomeIcon></a>
            </div>

    );


}

export default Carticon;