import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';

const Search = () => {

    return (

        <div>
            <a className="search-link" to="#"><FontAwesomeIcon icon={faSearch}></FontAwesomeIcon></a>
        </div>


    );


}

export default Search;