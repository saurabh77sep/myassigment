import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar } from '@fortawesome/free-solid-svg-icons';
import Search from './Search';
import Carticon from './Carticon';

const Header = () => {

    return (

        <div className="navbar">

            <div className="row">
                <div className="col-md-6" >
                    <a className="nav-link" to="#"><FontAwesomeIcon icon={faStar}></FontAwesomeIcon></a>
                </div>
                <div className="col-md-6">
                    <div className="CompJoin">
                        <p className="searchComp"><Search /></p>
                        <p className="searchIconComp"><Carticon /></p>

                    </div>
                </div>
            </div>

        </div>
    )

}


export default Header;